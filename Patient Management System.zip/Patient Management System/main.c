#include <stdio.h>
#include <stdlib.h>

#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>


 int add_pat();
 int view_app();
 int appointment();
 int patient();
 int view_pat();
 int searchpat();
 int cancel_app();
struct doctor
{               int id;
                char name[40];
                char fname[40];
                char speciality[100];
                int fee;

}input_1={1,"Dr. Sarim","Saleem","Bones",2000},
input_2={2,"Dr. Tanveer","Alam","Psycologist",5000},
input_3={3,"Dr. Divak","Maheshwari","Cancer Specialist",5000},
input_4={4,"Dr. Aashir","Asif","ENT",10000},
input_5={5,"Dr. Kashif","Aslam","Neurologist",2500};
int searchdocbyid();
int listdoc();
int doc();


    struct appointment {
	int pid;
	int appid;
	char name[100];
	int age;
	char disease[100];
	char date[10];
	char doc[100];
	int fees;
}; struct appointment p1,p2,p3,p4,p5,p6,p7;

int main(){
    int i;
    system("cls");
    system("color 4F");
	int choice;

	printf("\n\t\t\t\t******************************************");
	printf("\n\t\t\t\t******************************************");

	printf("\n\n\n\n\t\t\t\t\t****HANDY HEALTH HOSPITAL:****");
	printf("\n\n\n\n\t\t\t\t\t [1].PATIENT RECORD: \n\n");
	printf("\t\t\t\t\t [2].DOCTOR DETAILS: \n\n");
	printf("\t\t\t\t\t [3].APPOINTMENT: ");
	printf("\n\n\n\t\t\t\t******************************************");
	printf("\n\t\t\t\t******************************************");
	///printf("\t\t\t\t\t [4]")
	scanf("%d",&choice);

  switch(choice){
		case 1:
			patient();
		case 2:
            doc();
		case 3:
			appointment();
	}
}
int appointment(){
    int i;
    system("cls");
    system("color 4f");
	int choice;

	int apt;
	printf("\n\t\t\t\t******************************************");
	printf("\n\t\t\t\t******************************************");
	printf("\n\n\n\n\n\n\n\t\t\t\t\t [4].ADD NEW APPOINTMENT:\n\n");
	printf("\t\t\t\t\t [5].VIEW AN APPOINTMENT:\n\n");
	printf("\t\t\t\t\t [6].CANCEL AN APPOINTMENT:\n\n");
	printf("\t\t\t\t\t [7].GO TO MAIN MENU:\n\n");
	printf("\t\t\t\t\t SELECT:");
	printf("\n\n\n\n\t\t\t\t******************************************");
	printf("\n\t\t\t\t******************************************");
	scanf("%d",&apt);
	switch(apt){
	case 4:
		add_pat();
		break;
	case 5:
		view_app();
		break;
		case 6:
		cancel_app();
		break;
		case 7:
		main();
		break;
	}
}

int add_pat(){
    char ab ;
	int back;
	int i;
	system("cls");
    system("color 4F");
	int choice;
	for(i=1;i<=24;i++){
        printf("|*|");
	}
	for(i=1;i<=24;i++){
        printf("|||*|");
	}
	for(i=1;i<=24;i++){
        printf("|*|");
	}

     FILE *fp = fopen("pat.txt","a+");
     FILE *fp2 = fopen("appointment.txt","a+");
++p1.pid;
++p1.appid;
printf("\n\n\t\t\t\t Patient ID: %d",p1.pid);
printf("\n\n\t\t\t\t APPOINTMENT TOKEN NUMBER#: %d \n",p1.appid);
//scanf("%d",&p1.pid);
fflush(stdin);
printf("\n\t\t\t\t******************************************");
printf("\n\t\t\t\t******************************************\n");
printf("\n\t\t\t\t **Enter Patient's Name: ");
gets(p1.name);
 fflush(stdin);
printf("\n\t\t\t\t **Enter Patient's Age: ");
scanf("%d",&p1.age);
 fflush(stdin);
printf("\n\t\t\t\t **Enter Patient's Disease: ");
gets(p1.disease);
//scanf("%s",p1.disease);
 fflush(stdin);
printf("\n\t\t\t\t **Enter Appointment Date: ");
scanf("%s",&p1.date);
 fflush(stdin);
printf("\n\t\t\t\t **Enter Doctor's Name': ");
gets(p1.doc);
 fflush(stdin);
printf("\n\t\t\t\t **Enter Doctor's Fees: ");
scanf("%d",&p1.fees);
printf("\n\t\t\t\t******************************************");
printf("\n\t\t\t\t******************************************\n\n");
fflush(stdin);
printf("\n\t\t\t\t******RECORD SAVED: ******");
printf("\n\t\t\t\t** PATIENT: %s **",p1.name);
printf("\n\t\t\t\t** AGE: %d **",p1.age);
printf("\n\t\t\t\t** DISEASE: %s **",p1.disease);


    fprintf(fp,"\n%d\n %s %d %s\n",p1.pid,p1.name,p1.age,p1.disease);
      //   ID  APPID NAME AGE DIS date Doc Fees
    fprintf(fp2,"\n%d\n  %s  %s  %s  %s  Rs.%d\n",p1.appid,p1.name,p1.disease,p1.date,p1.doc,p1.fees);
fclose(fp);
fclose(fp2);
printf("\nENTER B TO GO BACK");
scanf("%c",&ab);
if(ab == 'b'){
    appointment();
}



    }

int view_app(){
    system("cls");
    int back,count2=0;
	FILE *fp;
	printf("\n\t\t\t\t******************************************");
    printf("\n\t\t\t\t******************************************\n\n");
	printf("ID      NAME      DIS      APT DATE      DOCTOR      FEES\n\n");

char name[200];
fp = fopen("appointment.txt","r");
	//printf("PATIENT ID APP TOKEN PATIENT's NAME AGE DISEASE DATE DOC FEES\n");

while(fscanf(fp, "%s",name)!=EOF){
    printf("%s      ",name);
    count2++;
    if(count2%6==0){
    	printf("\n\n");
	}
}
	printf("\n\t\t\t\t******************************************");
    printf("\n\t\t\t\t******************************************\n\n");
printf("\nPRESS 1 TO GO BACK:");
scanf("%d",&back);
switch(back){
	printf("Press 1 to go back");
case 1:
    appointment();
    break;
	}

                    //always use string %s
fclose(fp);
 }

int patient(){

    system("color 4F");
    system("cls");
	int choice;
	printf("\n\n\n\t\t\t\t\t [9].VIEW PATIENTS:\n\n");
//	printf("\t\t\t\t\t [10].DELETE A PATIENT:\n\n");
//	printf("\t\t\t\t\t [30].SEARCH A PATIENT:\n\n");
	printf("\t\t\t\t\t [20].MAIN MENU:\n\n");
	printf("\t\t\t\t\t CHOOSE YOUR OPTION: ");
	scanf("%d",&choice);
	switch(choice){
case 9:
    view_pat();
    break;
//case 30:
//    searchpat();
//    break;
    case 20:
    main();
    break;
    }
}


   int view_pat(){
   system("cls");
    int back;
    char ab = 'b';
	FILE *fp;
	printf("\n\t\t\t\t******************************************");
    printf("\n\t\t\t\t******************************************\n\n");
	printf("ID      NAME      AGE      DISEASE\n");
int count1=0;
char name[200];
fp = fopen("pat.txt","r");
	//printf("PATIENT ID APP TOKEN PATIENT's NAME AGE DISEASE DATE DOC FEES\n");
while(fscanf(fp, "%s",name)!=EOF){
    printf("%s      ",name);

    count1++;
    if(count1%4==0){
    	printf("\n");
	}
}
printf("\n\n\n\nPRESS B TO GO BACK:");
    getche();
    {
        if(ab=='b'){
            patient();
        }
    }
}

int cancel_app(){
    char ab= 'b';
    system("cls");
    FILE *fp = fopen("pat.txt","w");
     FILE *fp2 = fopen("appointment.txt","w");
     if(fp2 == NULL){
        printf("\n\n\t\t\t\tADD A RECORD:\n");
        printf("\t\t\t\tPRESS B TO GO BACK:");
getche();
if(ab == 'b'){
    main();
}
     }
     else
     fprintf(fp2," ");
fclose(fp);
printf("\n\n\t\t\t\tALL RECORDS ARE DELETED:\n");
printf("\t\t\t\tPRESS B TO GO BACK:");
getche();
if(ab == 'b'){
    main();
}
    }

 int doc() {
     system("cls");
system("color 4F");
    int c;
 printf("\n\t\t\t\tChoose one option:\n");
printf("\t\t\t\t[13].VIEW DOCTORS LIST\n");
printf("\t\t\t\t[14].SEARCH DOCTOR BY ID\n");
printf("\t\t\t\t[15].MAIN MENU:\n\n");
printf("\t\t\t\t CHOOSE ONE OPTION\n");
scanf("%d",&c);
    switch (c)
    {
    case 13:
        listdoc();
        break;
    case 14:
        searchdocbyid();
        break;
      case 15:
        main();
        break;
    }
    getche();


 }
 int searchdocbyid()
 {
     int id;
     int back;
     printf("Enter ID no (1-5) of doctor to view details :");
      scanf("%d",&id);
      if (id==1)
      {
	        struct doctor input_1 ={1,"Dr.Sarim","Saleem","Bones",2000};
            printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d",input_1.id,input_1.name,input_1.fname,input_1.speciality,input_1.fee);
      }
    else if (id==2)
      {struct doctor input_2 ={2,"Dr.Tanveer","Alam","Psycologist",5000};
      printf("\nID:%d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d",input_2.id,input_2.name,input_2.fname,input_2.speciality,input_2.fee);
      }
      else if (id==3)
      {struct doctor input_3 ={3,"Dr.Divak","Maheshwari","Cancer specialist",5000};
      printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d",input_3.id,input_3.name,input_3.fname,input_3.speciality,input_3.fee);
      }
      else if (id==4)
      {struct doctor input_4 ={4,"Dr.Aashir","Asif","ENT",10000};
      printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d",input_4.id,input_4.name,input_4.fname,input_4.speciality,input_4.fee);
      }
    else if (id==5)
      {struct doctor input_5 ={5,"Kashif","Aslam","Brain",2500};
      printf("\nId: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d",input_5.id,input_5.name,input_5.fname,input_5.speciality,input_5.fee);
      }
      printf("\nEnter 6 To Go Back: ");
      scanf("%d",&back);
      switch (back)
      {
      	case 6:
      		doc();
	  }

getche();
 }
listdoc()
{
	int back;
printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d\n\n",input_1.id,input_1.name,input_1.fname,input_1.speciality,input_1.fee);
printf("\n********************************");
printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d\n\n",input_2.id,input_2.name,input_2.fname,input_2.speciality,input_2.fee);
printf("\n********************************");
printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d\n\n",input_3.id,input_3.name,input_3.fname,input_3.speciality,input_3.fee);
printf("\n********************************");
printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d\n\n",input_4.id,input_4.name,input_4.fname,input_4.speciality,input_4.fee);
printf("\n********************************");
printf("\nID: %d \nFirst Name: %s \nLast Name: %s \nSpeciality: %s \nFees: %d\n\n",input_5.id,input_5.name,input_5.fname,input_5.speciality,input_5.fee);
printf("\n********************************");
printf("\nEnter 6 To Go Back: ");
      scanf("%d",&back);
      switch (back)
      {
      	    case 6:
      		doc();
}
getche();
}
